// for (let i = 1; i < 11; i++) {
//     a = '<div class="detail_box">';
//     a += '<div class="radio_img">';
//     a += '<div class="play_time">01:08:39</div>';
//     a += '<div class="play_mask">';
//     a += '<img class="play_img" src="./img/play.png" alt="">';
//     a += '</div>';    
//     a += '</div>';
//     a += '<div class="introduce">[112期]甲乙方视角的安全预警体系建设</div>';
//     a += '<div class="author">团长</div>';
//     a += '<div class="tag_box">';
//     a += '<div class="box">';
//     a += '<div>';
//     a += '<img class="tag_img" src="./img/play_icon.png" alt="">';    
//     a += '</div>';        
//     a += '<span>4109</span>';    
//     a += '</div>';    
//     a += '<div class="box">';
//     a += '<div>';
//     a += '<img class="tag_img" src="./img/message.png" alt="">';    
//     a += '</div>';        
//     a += '<span>345</span>';    
//     a += '</div>';    
//     a += '</div>';
//     a += '</div>';
//     $(".test").append(a);
// }