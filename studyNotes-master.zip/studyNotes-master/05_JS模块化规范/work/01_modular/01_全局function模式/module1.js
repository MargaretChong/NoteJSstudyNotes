let msg = 'module'

function foo(){
    console.log('foo()', msg);
}

function bar(){
    console.log('bar()', msg);
}