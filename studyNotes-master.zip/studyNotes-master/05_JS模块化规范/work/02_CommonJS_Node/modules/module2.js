// 暴露一个函数， module.exports = function(){}

module.exports = function(){
    console.log("module2");
}