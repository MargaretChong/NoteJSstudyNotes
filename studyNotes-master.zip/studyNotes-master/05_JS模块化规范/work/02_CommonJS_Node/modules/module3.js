// exports.xxxx = value

exports.foo = function (){
    console.log('foo () module3');
};
exports.bar = function (){
    console.log('bar () module3');
};

exports.arr = [2,12,5,1,2,6,4,5,2]