// 统一暴露

function fun(){
    console.log('fun() module2');
}
function fun2(){
    console.log('fun2() module2');
}

export {fun, fun2};