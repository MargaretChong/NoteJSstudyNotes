var math = require("math");

console.log(math.add(100,100));