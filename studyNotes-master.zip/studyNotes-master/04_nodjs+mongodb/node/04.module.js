var a = 10;

// console.log(global.a);
// arguments.callee  保存的时当前执行的函数对象
console.log(arguments.length);