var hello = require("./helloModule");

console.log(hello.name);
