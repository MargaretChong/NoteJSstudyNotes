/*
*   模块化
* */

console.log("我是模块化,02");

var x = 10;
var y = 10;

exports.x = "我是02中的变量"