
var md = require("./02.module.js");
console.log(md);

